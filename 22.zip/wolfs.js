const { ButtonStyle, ButtonBuilder, EmbedBuilder, ActionRowBuilder, AttachmentBuilder } = require("discord.js");
const config = require("./config");
const has_play = new Map();

async function sendError(client, error) {
  const errorChannel = await client.channels.fetch(config.errorChannelId);
  if (errorChannel) {
    errorChannel.send(`❗ An error occurred: \n\`\`\`${error.message}\n${error.stack}\`\`\``).catch(console.error);
  } else {
    console.error('Error channel not found');
  }
}

async function mafia_command(message) {
  try {
    if (has_play.get(message.guild.id)) return message.reply({ content: `❌ هناك بالفعل لعبة فعالة في هذا السيرفر!` });
    let time = 50000;
    let data = {
      author: message.author.id,
      players: [],
      start_in: Date.now() + time,
      type: "mafia"
    }
    const mention = '@everyone';
    const attachment = new AttachmentBuilder('./s2.png');

    const embed = new EmbedBuilder()
      .setColor("#1c2935")
      .setTitle("Werewolf")
      .setDescription(`__ستبدأ اللعبة خلال__: **<t:${Math.floor(data.start_in / 1000)}:R>**`);

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId('join_mafia')
          .setLabel('دخول'),
        new ButtonBuilder()
          .setStyle(ButtonStyle.Secondary)
          .setCustomId('left_mafia')
          .setLabel('خروج')
      );

    let msg = await message.channel.send({
      content: mention,
      files: [attachment],
      components: [row]
    });

    has_play.set(message.guild.id, data);

    let start_c = msg.createMessageComponentCollector({ time: time });
    start_c.on("collect", async inter => {
      try {
        if (!has_play.get(message.guild.id)) return;
        if (inter.customId === "join_mafia") {
          if (data.players.find(u => u.id == inter.user.id)) return inter.reply({ content: `لقد سجلت بالفعل.`, ephemeral: true });
          if (data.players.length >= 20) return inter.reply({ content: `عدد المشاركين مكتمل`, ephemeral: true });
          data.players.push({
            id: inter.user.id,
            username: inter.user.displayName,
            avatar: inter.user.displayAvatarURL({ dynamic: true, format: "png" }),
            type: "person",
            interaction: inter,
            vote_kill: 0,
            vote_kick: 0
          });
          has_play.set(message.guild.id, data);
          embed.setDescription(`**<t:${Math.floor(data.start_in / 1000)}:R>**
__اللاعبين المشاركين:__ **(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`);
          let playerCount = data.players.length;
          await msg.edit({ content: `** @here العدد الحالي للاعبين**: ${playerCount}`, components: [row] }).catch(err => sendError(message.client, err));
          inter.reply({ content: `✅ تم الدخول الى اللعبة   `, ephemeral: true });
        } else if (inter.customId == "left_mafia") {
          let index = data.players.findIndex(i => i.id == inter.user.id);
          if (index == -1) return inter.reply({ content: `❌ - انت غير مشارك بالفعل`, ephemeral: true });
          data.players.splice(index, 1);
          has_play.set(message.guild.id, data);
          embed.setDescription(`**<t:${Math.floor(data.start_in / 1000)}:R>**
__اللاعبين المشاركين:__ **(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`);
          msg.edit({ embeds: [embed] }).catch(err => sendError(message.client, err));
          inter.reply({ content: `✅ تم إزالتك من المشتركين`, ephemeral: true });
        }
      } catch (err) {
        sendError(message.client, err);
      }
    });
    start_c.on("end", async (end, reason) => {
      try {
        if (!has_play.get(message.guild.id)) return;
        embed.setDescription(`*(${data.players.length}/20)**
${data.players.map(p => `- <@${p.id}>`).join("\n")}
`)
          .setColor("Red");
        if (data.players.length < 1) {
          has_play.delete(message.guild.id);
          return message.channel.send({ content: `🚫 - تم إلغاء اللعبة لعدم وجود 7 لاعبين على الأقل` });
        }
        let c = 7;
let mafiaCount = 0;

if (data.players.length >= 5 && data.players.length <= 7) {
  mafiaCount = 1;
} else if (data.players.length >= 9 && data.players.length <= 14) {
  mafiaCount = 2;
} else if (data.players.length > 14) {
  mafiaCount = 3;
}

for (let i = 0; i < data.players.length; i += c) {
  let array = data.players.slice(i, i + c);
  if (i == 0) {
    // Assign roles for the first segment
    let mafia_i = Math.floor(Math.random() * array.length);
    let mafia = array[mafia_i];
    array.splice(mafia_i, 1);
    let mafia_index = data.players.findIndex(m => m.id == mafia.id);
    if (mafia_index != -1) {
      data.players[mafia_index].type = "mafia";
    }

    let seer_i = Math.floor(Math.random() * array.length);
    let seer = array[seer_i];
    let seer_index = data.players.findIndex(m => m.id == seer.id);
    data.players[seer_index].type = "seer";

    let doctor_i = Math.floor(Math.random() * array.length);
    let doctor = array[doctor_i];
    let doctor_index = data.players.findIndex(m => m.id == doctor.id);
    data.players[doctor_index].type = "doctor";
// Add Alpha Werewolf role assignment in the mafia_command function
if (data.players.length > 7) {
  // Add Alpha Werewolf role
  let alphaWerewolf_i = Math.floor(Math.random() * data.players.length);
  let alphaWerewolf = data.players[alphaWerewolf_i];
  let alphaWerewolf_index = data.players.findIndex(p => p.id == alphaWerewolf.id);
  if (alphaWerewolf_index != -1) {
    data.players[alphaWerewolf_index].type = "alpha_werewolf";
  }
}
    if (data.players.length > 7) {
      // Add Jester role
      let jester_i = Math.floor(Math.random() * data.players.length);
      let jester = data.players[jester_i];
      let jester_index = data.players.findIndex(p => p.id == jester.id);
      if (jester_index != -1) {
        data.players[jester_index].type = "jester";
      }
    }
  } else {
    // Assign mafia roles based on mafiaCount
    for (let j = 0; j < mafiaCount; j++) {
      if (array.length > 0) {
        let mafia_i = Math.floor(Math.random() * array.length);
        let mafia = array[mafia_i];
        let mafia_index = data.players.findIndex(m => m.id == mafia.id);
        if (mafia_index != -1) {
          data.players[mafia_index].type = "mafia";
        }
        array.splice(mafia_i, 1); // Remove mafia from the array
      }
    }
  }
}

has_play.set(message.guild.id, data);

for (let player of data.players) {
  if (player.type == "person") {
    await player.interaction.followUp({ content: `👥 | تم اختيارك انت كـ **مواطن**. في كل جولة يجب عليك التحقق مع جميع اللاعبين لأكتشاف الذئاب وطردهم من اللعبة`, ephemeral: true }).catch(err => sendError(message.client, err));
  } else if (player.type == "doctor") {
    await player.interaction.followUp({ content: `🧑‍⚕️ | تم اختيارك انت كـ **الطبيب**. في كل جولة يمكنك حماية شخص واحد من هجوم الذئاب`, ephemeral: true }).catch(err => sendError(message.client, err));
  } else if (player.type == "mafia") {
    await player.interaction.followUp({ content: `🐺  | تم اختيارك انت كـ **ذئب**. يجب عليكم محاولة اغتيال جميع اللاعبين بدون اكتشافكم`, ephemeral: true }).catch(err => sendError(message.client, err));
  } else if (player.type == "seer") {
    await player.interaction.followUp({ content: `🧙‍♂️ | تم اختيارك انت كـ **العراف**. يمكنك التحقق من أحد اللاعبين في كل جولة لمعرفة إذا كان ذئب`, ephemeral: true }).catch(err => sendError(message.client, err));
  } else if (player.type == "jester") {
    await player.interaction.followUp({ content: `🎭 | تم اختيارك كـ **المهرج**. هدفك هو أن تكون مطروداً من اللعبة. إذا فاز أحد الجانبين، ستفوز أيضاً.`, ephemeral: true }).catch(err => sendError(message.client, err));
  }else if (player.type == "alpha_werewolf") {
    await player.interaction.followUp({ content: `🐺 | تم اختيارك كـ **ذئب الفا**. ستكون غير مرئي للعراف، ولكنك ستظل عضوًا في فريق الذئاب.` , ephemeral: true }).catch(err => sendError(message.client, err));
  }
  
}

        message.channel.send({
          content: `
✅ تم توزيع الرتب على اللاعبين. ستبدأ الجولة الأولى في بضع ثواني...
`
        });
        await sleep(700);
        await mafia(message);
      } catch (err) {
        sendError(message.client, err);
      }
    });
  } catch (err) {
    sendError(message.client, err);
  }
}

// Remaining functions (mafia, restart, win, createMultipleButtons, createButton, sleep) with similar try-catch blocks

async function mafia(message) {
  if (!message || !message.guild) return;
  let data = has_play.get(message.guild.id);
  if (!data) return;
  let mafia = data.players.filter(t => t.type == "mafia" || t.type == "alpha_werewolf");
// Ensure Alpha Werewolf is part of the mafia team but invisible to Seer
  let doctor = data.players.find(t => t.type == "doctor");
  let person = data.players.filter(t => t.type != "mafia");
  let seer = data.players.find(t => t.type == "seer");
  let person_buttons = createMultipleButtons(person.map((p) => ({ id: p.id, label: p.username, disabled: false, index: person.findIndex(u => u.id == p.id) })), "kill");
  for (let m of mafia) {
    await m.interaction.followUp({ content: `أمامك 20 ثانية لاختيار صيده   `, components: person_buttons, ephemeral: true }).catch(() => 0);
  }
  message.channel.send({ content: `🔪 | جاري انتظار الذئاب لاختيار شخص لصيده...` });
  let kill_c = message.channel.createMessageComponentCollector({ 
    filter: m => mafia.some(n => n.id === m.user.id) && m.customId.startsWith("kill"), 
    time: 20000 
  });
  let collected = [];
  
  kill_c.on("collect", async inter => {
    if (!has_play.get(message.guild.id)) return;
    if (collected.includes(inter.user.id)) return;
  
    collected.push(inter.user.id);
    await inter.update({ content: `تم التصويت بنجاح انتظر النتيجة`, components: [] }).catch(() => 0);
  
    let index = inter.customId.split("_")[2];
    person[index].vote_kill += 1;
  
    if (collected.length >= mafia.length) return kill_c.stop();
  });
  
  kill_c.on("end", async (collectedComponents, reason) => {
    if (!has_play.get(message.guild.id)) return;
    
    // Sort persons by vote_kill in descending order
    person = person.sort((a, b) => b.vote_kill - a.vote_kill);
    
    // Check if a mafia member has not collected a vote
    for (let maf of mafia) {
      if (!collected.includes(maf.id)) {
        let index = mafia.findIndex(m => m.id === maf.id);
        if (index !== -1) {
          mafia.splice(index, 1);
          
          if (mafia.length >= 1) {
            let playerIndex = data.players.findIndex(m => m.id === maf.id);
            if (playerIndex !== -1) {
              data.players.splice(playerIndex, 1);
              has_play.set(message.guild.id, data);
            }
            message.channel.send({ 
              content: `🕐 | تم طرد <@${maf.id}> من الذئاب لعدم تفاعله... ستبدأ الجولة التالية في غضون ثوانٍ قليلة` 
            });
            await sleep(1000);
            restart(message);
          } else {
            message.channel.send({ 
              content: `🕐 | تم طرد <@${maf.id}> من الذئاب لعدم تفاعله...` 
            });
            win(message, "person");
          }
          return;
        }
      }
    }
    
    // Proceed with the killing process
    let killed_person = person[0];
    message.channel.send({ content: `🔪 | اختارت الذائب الشخص الذي سيتم صيده` });
    await sleep(1000);
  
    let id = null;
    if (doctor) {
      message.channel.send({ 
        content: `🩺 | جاري انتظار الطبيب لاختيار شخص لحمايته...` 
      });
  
      let all_buttons = createMultipleButtons(
        data.players.map(p => ({
          id: p.id,
          label: p.username,
          disabled: false,
          index: data.players.findIndex(u => u.id === p.id)
        })), 
        "protect"
      );
  
      await doctor.interaction.followUp({ 
        content: `أمامك **20** ثانية لاختيار شخص لحمايته...`, 
        components: all_buttons, 
        ephemeral: true, 
        fetchReply: true 
      }).catch(() => 0);
  
      let doctor_collect = await message.channel.awaitMessageComponent({ 
        filter: m => m.user.id === doctor.id && m.customId.startsWith("protect"), 
        time: 20000 
      }).catch(() => 0);
  
      if (!doctor_collect || !doctor_collect.customId) {
        message.channel.send({ content: `🩺 | لم يختر الطبيب أحد ليحميه من الصيد` });
      } else {
        message.channel.send({ content: `🩺 | اختار الطبيب الشخص الذي سيحميه من اغتيال الذئاب` });
      }
      id = doctor_collect ? doctor_collect.customId.split("_")[1] : null;
    }
  
    if (id === killed_person.id) {
      message.channel.send({ content: `🛡️ | فشلت عملية الذئاب لصيد <@${killed_person.id}> لأنه تم حمايته من قبل الطبيب` });
    } else {
      let playerIndex = data.players.findIndex(b => b.id === killed_person.id);
      if (playerIndex !== -1) {
        data.players.splice(playerIndex, 1);
        has_play.set(message.guild.id, data);
      }
      await message.channel.send({ 
        content: `⚰️ | نجحت عملية الذئاب وتم قتل <@${killed_person.id}> وهذا الشخص كان **${killed_person.type === "doctor" ? "طبيب" : killed_person.type === "jester" ? "مهرج" : killed_person.type === "seer" ? "عراف" : "مواطن"}**` 
      });
    }  
    if (seer) {                                                                                                          ////jester
      message.channel.send({ content: `🔍 | جاري انتظار العراف لاختيار شخص للتحقق منه...` });
      let all_buttons = createMultipleButtons(data.players.map((p) => ({ id: p.id, label: p.username, disabled: false, index: data.players.findIndex(u => u.id == p.id) })), "check");
      await seer.interaction.followUp({ content: `أمامك **20** ثانية لاختيار شخص للتحقق منه...`, components: all_buttons, ephemeral: true }).catch(() => 0);
      let seer_collect = await message.channel.awaitMessageComponent({ filter: m => m.user.id == seer.id && m.customId.startsWith("check"), time: 20000 }).catch(() => 0);
      if (seer_collect && seer_collect.customId) {
        let checked_player = data.players.find(p => p.id == seer_collect.customId.split("_")[1]);
        if (checked_player.type == "alpha_werewolf") {
          await seer.interaction.followUp({ content: `🧙‍♂️ | الشخص الذي تحققت منه هو **مواطن**.`, ephemeral: true }).catch(() => 0);
        } else if (checked_player.type == "mafia") {
          await seer.interaction.followUp({ content: `🧙‍♂️ | الشخص الذي تحققت منه هو **ذئب**.`, ephemeral: true }).catch(() => 0);
        } else {
          await seer.interaction.followUp({ content: `🧙‍♂️ | الشخص الذي تحققت منه هو **${checked_player.type}**.`, ephemeral: true }).catch(() => 0);
        }      
      } else {
          message.channel.send({ content: `🔍 | لم يختر العراف أحدًا للتحقق منه.` });
      }
  }
  if (data.players.filter(b => b.type == "person").length <= data.players.filter(b => b.type == "mafia").length) {
    return win(message, "mafia");
}

message.channel.send({ content: `🔍 | لديكم **30 ثانية** للتحقق بين اللاعبين ومعرفة الذيب للتصويت على طرده من اللعبة` });
await sleep(10000);

let all = data.players.map(m => m);
let all_buttons = createMultipleButtons(
    all.map((p) => ({
        id: p.id,
        label: p.username,
        disabled: false,
        emoji: config.numbers[p.vote_kick],
        index: data.players.findIndex(u => u.id === p.id)
    })),
    "kick"
);

let msg = await message.channel.send({
    content: `لديكم **20 ثانية** لاختيار شخص لطرده من اللعبة`,
    components: all_buttons
});

let kick_c = msg.createMessageComponentCollector({
    filter: n => data.players.find(m => m.id === n.user.id) && n.customId.startsWith("kick"),
    time: 30000  // 30 seconds for voting
});

let collected_1 = [];

kick_c.on("collect", async inter => {
    if (!has_play.get(message.guild.id)) return;

    if (collected_1.includes(inter.user.id)) return;  // Prevent multiple votes from the same user

    collected_1.push(inter.user.id);

    let user_id = inter.customId.split("_")[1];
    let index = all.findIndex(i => i.id === user_id);

    if (index !== -1) {
        all[index].vote_kick += 1;

        let all_buttons_2 = createMultipleButtons(
            all.map((p) => ({
                id: p.id,
                label: p.username,
                disabled: false,
                emoji: config.numbers[p.vote_kick],
                index: data.players.findIndex(u => u.id === p.id)
            })),
            "kick"
        );

        await msg.edit({ components: all_buttons_2 }).catch(() => 0);  // Update vote counts
    }

    await inter.update({ 
        content: `تم التصويت بنجاح انتظر النتيجة`, 
        components: [] 
    }).catch(() => 0);  // Confirm vote and disable buttons for this user
});

kick_c.on("end", collected => {
    // Process the results after 30 seconds
    let highestVotes = Math.max(...all.map(p => p.vote_kick));
    let kickedPlayer = all.find(p => p.vote_kick === highestVotes);

    if (kickedPlayer) {
        message.channel.send(`تم طرد <@${kickedPlayer.id}> من اللعبة بسبب حصوله على أكبر عدد من الأصوات.`);
        // You can implement the actual kick logic here
    } else {
        message.channel.send("لم يتم طرد أي لاعب لعدم وجود إجماع.");
    }
});

    kick_c.on("end", async (end, reason) => {
      if (!has_play.get(message.guild.id)) return;
      
      // Create an embed with updated vote counts
      const voteEmbed = new EmbedBuilder()
        .setTitle('Voting Results')
        .setColor("#1c2935")
        .setDescription(
          data.players
            .map((player) => `**${player.username}**: ${player.vote_kick} votes`)
            .join('\n')
        );
      
      // Disable all buttons after voting ends
      let all_buttons_2 = createMultipleButtons(all.map((p) => ({
        id: p.id, 
        label: p.username, 
        disabled: true, 
        index: data.players.findIndex(u => u.id == p.id) 
      })), "kick");
    
      // Edit the message with the new embed and disabled buttons
      await msg.edit({ embeds: [voteEmbed], components: all_buttons_2 }).catch(() => 0);
      
      // Determine the result of the vote
      let choices = all.sort((a, b) => b.vote_kick - a.vote_kick);
      if (choices[0].vote_kick == choices[1].vote_kick) {
        message.channel.send({ content: `⏭ | بسبب تعادل التصويت ، تم تخطي الطرد ... الجولة القادمة ستبدأ في بضع ثوان` });
        await sleep(1000);
        await restart(message);
      } else {
        let kicked = choices[0];
        let index = data.players.findIndex(i => i.id == kicked.id);
        if (index != -1) {
          data.players.splice(index, 1);
          has_play.set(message.guild.id, data);
        }
        message.channel.send({ content: `💣 | تم التصويت على طرد <@${kicked.id}> وكان هذا الشخص **${kicked.type == "mafia" ? "ذيب" : kicked.type == "seer" ? "عراف" : kicked.type == "doctor" ? "طبيب" :kicked.type == "jester" ? "مهرج": "مواطن"}**` });
        if(data.players.filter(b => b.type == "person").length <= data.players.filter(b => b.type == "mafia").length) return win(message, "mafia");
        if(data.players.filter(b => b.type == "mafia").length <= 0) return win(message, "person");
        message.channel.send({ content: `ستبدأ الجولة التالية بعد بضع ثوان...` });
        await sleep(1000);
        restart(message);
      }
    });    
});
}

function restart(message) {
  mafia(message);
}

const { createCanvas, loadImage } = require('canvas');

async function createWinImage(imageUrl, winners, losers, jester) {
    try {
        // Load the image
        const img = await loadImage(imageUrl);

        // Create a canvas
        const canvas = createCanvas(img.width, img.height);
        const ctx = canvas.getContext('2d');

        // Draw the base image
        ctx.drawImage(img, 0, 0);

        // Add winner avatars (assuming you have the avatar URLs)
        await Promise.all(winners.map(async (winner, index) => {
            const avatar = await loadImage(winner.avatarUrl);
            ctx.drawImage(avatar, 50, 50 + (index * 100), 50, 50); // Positioning of avatars
        }));

        // Add loser avatars similarly...

        // Add jester avatar if any...
        if (jester) {
            const jesterAvatar = await loadImage(jester.avatarUrl);
            ctx.drawImage(jesterAvatar, 50, canvas.height - 100, 50, 50);
        }

        // Return the image as a buffer
        return canvas.toBuffer();
    } catch (error) {
        console.error('Error loading or processing the image:', error);
    }
  }
  async function win(message, who) {
    let data = has_play.get(message.guild.id);
    if (!data) return;
  
    // Define winners, losers, and jesterWinners based on the game outcome
    let winners, losers;
    let jesterWinners = data.players.filter(p => p.type === "jester");
  
    if (who === "person") {
      winners = data.players.filter(p => p.type !== "mafia");
      losers = data.players.filter(p => p.type === "mafia");
      messageContent = `**👑 | فاز الفريق الأول (المواطنين) في اللعبة.**\n${winners.map(b => `<@${b.id}>`).join(", ")}`;
    } else if (who === "mafia") {
      winners = data.players.filter(p => p.type === "mafia");
      losers = data.players.filter(p => p.type !== "mafia");
      messageContent = `**👑 | فاز الفريق الثاني (الذئاب) في اللعبة.**\n${winners.map(b => `<@${b.id}>`).join(", ")}`;
    }
  
    if (jesterWinners.length > 0) {
      messageContent += `**\n🎭 | المهرج فاز باللعبة لأنه تم طرده أو فاز أحد الفريقين.**\n${jesterWinners.map(b => `<@${b.id}>`).join(", ")}`;
    }
  
    // Here you should pass the variables winners, losers, and jesterWinners to the image creation function
    try {
      const imageBuffer = await createWinImage(imageUrl, winners, losers, jesterWinners[0]);
      const attachment = new MessageAttachment(imageBuffer, 'game_result.png');
      await message.channel.send({ content: messageContent, files: [attachment] });
    } catch (err) {
      console.error("Error creating win image:", err);
    }
  }
  


function createMultipleButtons(array, type) {
  let components = [];
  let c = 5;
  for (let i = 0; i < array.length; i += c) {
    let buttons = array.slice(i, i + c);
    let component = new ActionRowBuilder()
    for (let button of buttons) {
      let btn = new ButtonBuilder()
        .setStyle(ButtonStyle.Secondary)
        .setLabel(button.label) // Only show player names
        .setCustomId(`${type}_${button.id}_${button.index}`)
        .setDisabled(button.disabled ? button.disabled : false);
      component.addComponents(btn);
    }
    components.push(component);
  }
  return components;
}


function createButton(style, customId, label, emoji, disabled) {
  let styles = {
    PRIMARY: ButtonStyle.Primary,
    SECONDARY: ButtonStyle.Secondary,
    SUCCESS: ButtonStyle.Success,
    DANGER: ButtonStyle.Danger
  }
  let btn = new ButtonBuilder()
    .setStyle(styles[style])
    .setCustomId(customId)
    .setLabel(label)
    .setDisabled(disabled ? disabled : false);
  if (emoji) btn.setEmoji(emoji);
  return btn;
}

function sleep(time) {
  return new Promise((resolve) => setTimeout(() => resolve(time), time));
}

module.exports = mafia_command;