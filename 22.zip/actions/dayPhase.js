const vote_phase = require('./votePhase');
const check_win_conditions = require('./checkWinConditions');

async function day_phase(message, data) {
  message.channel.send("🌞 تبدأ المرحلة النهارية الآن!");

  // Voting phase
  await vote_phase(message, data);

  // Check for end of game conditions
  await check_win_conditions(message, data);
}

module.exports = day_phase;
