class Werewolf {
  constructor(player) {
    this.id = player.id;
    this.username = player.username;
    this.avatar = player.avatar;
    this.type = "werewolf";
    this.interaction = player.interaction;
  }
}

module.exports = Werewolf;
