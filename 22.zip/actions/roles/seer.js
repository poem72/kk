class Seer {
  constructor(player) {
    this.id = player.id;
    this.username = player.username;
    this.avatar = player.avatar;
    this.type = "seer";
    this.interaction = player.interaction;
  }
}

module.exports = Seer;
