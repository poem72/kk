const { ButtonBuilder, ActionRowBuilder, ButtonStyle } = require('discord.js');

async function vote_phase(message, data) {
  message.channel.send("🗳️ Voting has started! Use the buttons below to vote for who you think is a werewolf.");

  // Create buttons for each player
  let rows = [];
  let row = new ActionRowBuilder();

  data.players.forEach((player, index) => {
    let button = new ButtonBuilder()
      .setCustomId(`vote_${player.id}`)
      .setLabel(player.username)
      .setStyle(ButtonStyle.Primary);

    row.addComponents(button);

    // Create a new row if the current one has reached the limit of 5 buttons
    if ((index + 1) % 5 === 0) {
      rows.push(row);
      row = new ActionRowBuilder();
    }
  });

  // Add the last row if it contains any buttons
  if (row.components.length > 0) rows.push(row);

  // Send the message with the voting buttons
  let voteMessage = await message.channel.send({
    content: "Cast your votes!",
    components: rows
  });

  // Set up a collector to gather votes
  let votes = new Map();

  const collector = voteMessage.createMessageComponentCollector({ time: 30000 }); // 30 seconds to vote

  collector.on('collect', async (interaction) => {
    if (!interaction.isButton()) return;

    // Record the vote
    let votedPlayerId = interaction.customId.split('_')[1];
    votes.set(interaction.user.id, votedPlayerId);

    await interaction.reply({ content: `You voted for ${data.players.find(p => p.id === votedPlayerId).username}.`, ephemeral: true });
  });

  collector.on('end', async () => {
    // Tally the votes
    let voteCounts = {};

    for (let votedPlayerId of votes.values()) {
      if (!voteCounts[votedPlayerId]) voteCounts[votedPlayerId] = 0;
      voteCounts[votedPlayerId]++;
    }

    // Determine who has the most votes
    let maxVotes = 0;
    let eliminatedPlayerId = null;

    for (let [playerId, count] of Object.entries(voteCounts)) {
      if (count > maxVotes) {
        maxVotes = count;
        eliminatedPlayerId = playerId;
      }
    }

    if (eliminatedPlayerId) {
      let eliminatedPlayer = data.players.find(p => p.id === eliminatedPlayerId);
      message.channel.send(`⚖️ The village has decided! ${eliminatedPlayer.username} has been eliminated.`);
      data.players = data.players.filter(p => p.id !== eliminatedPlayerId);
    } else {
      message.channel.send("⚖️ No one was eliminated.");
    }

    // Continue to check win conditions or move to the next phase
    await check_win_conditions(message, data);
  });
}
